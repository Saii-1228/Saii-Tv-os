package com.saii.saiiostv

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "saii_launcher")
class FavoritesStore(private val context: Context) {
    private val key = stringSetPreferencesKey("favorite_packages")

    val favorites: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[key] ?: emptySet()
    }

    suspend fun toggle(packageName: String) {
        context.dataStore.edit { prefs ->
            val updated = (prefs[key] ?: emptySet()).toMutableSet()
            if (!updated.add(packageName)) updated.remove(packageName)
            prefs[key] = updated
        }
    }
}
