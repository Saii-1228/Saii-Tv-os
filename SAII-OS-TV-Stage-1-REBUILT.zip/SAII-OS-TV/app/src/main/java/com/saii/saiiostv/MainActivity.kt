package com.saii.saiiostv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val Ink = Color(0xFF050505)
private val Panel = Color(0xFF17191B)
private val Silver = Color(0xFFC4C8CC)
private val Muted = Color(0xFF858A90)
private val White = Color(0xFFF5F5F5)

class MainActivity : ComponentActivity() {
    private lateinit var repository: AppRepository
    private lateinit var favoritesStore: FavoritesStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = AppRepository(this)
        favoritesStore = FavoritesStore(this)
        setContent {
            MaterialTheme {
                LauncherRoot(
                    repository = repository,
                    favoritesStore = favoritesStore
                )
            }
        }
    }
}

@Composable
private fun LauncherRoot(
    repository: AppRepository,
    favoritesStore: FavoritesStore
) {
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var page by remember { mutableStateOf("HOME") }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val favorites by favoritesStore.favorites.collectAsState(initial = emptySet())

    androidx.compose.runtime.LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { repository.loadLaunchableApps() }
    }

    BackHandler(enabled = page != "HOME") { page = "HOME" }

    Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 52.dp, vertical = 30.dp)
        ) {
            Header()
            Spacer(Modifier.height(22.dp))
            when (page) {
                "HOME" -> HomePage(
                    apps = apps.filter { it.packageName in favorites }.ifEmpty { apps.take(8) },
                    allApps = apps,
                    favorites = favorites,
                    onLaunch = { pkg ->
                        message = if (repository.launch(pkg)) null else "This app could not be opened."
                    },
                    onToggleFavorite = { pkg -> scope.launch { favoritesStore.toggle(pkg) } },
                    onShowApps = { page = "APPS" }
                )
                "APPS" -> AppsPage(
                    apps = apps,
                    favorites = favorites,
                    onLaunch = { pkg ->
                        message = if (repository.launch(pkg)) null else "This app could not be opened."
                    },
                    onToggleFavorite = { pkg -> scope.launch { favoritesStore.toggle(pkg) } }
                )
                else -> SimplePage(page)
            }
            Spacer(Modifier.weight(1f))
            NavigationBar(current = page, onSelect = { page = it })
            message?.let {
                Text(it, color = Silver, modifier = Modifier.padding(top = 8.dp), fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun Header() {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = LocalDateTime.now()
        }
    }
    val time = now.format(DateTimeFormatter.ofPattern("h:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM"))
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("SAII OS", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("TELEVISION", color = Muted, fontSize = 10.sp, letterSpacing = 4.sp)
        }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(time, color = White, fontSize = 22.sp, fontWeight = FontWeight.Light)
            Text(date, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun HomePage(
    apps: List<AppInfo>,
    allApps: List<AppInfo>,
    favorites: Set<String>,
    onLaunch: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onShowApps: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("A calmer way to watch.", color = White, fontSize = 34.sp, fontWeight = FontWeight.Light)
        Text("YOUR TELEVISION. YOUR SPACE.", color = Muted, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(28.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(
                modifier = Modifier.weight(1.2f)
                    .background(Panel, RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF33383D), RoundedCornerShape(18.dp))
                    .padding(22.dp)
            ) {
                Text("FAVOURITES", color = Silver, fontSize = 11.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(14.dp))
                if (apps.isEmpty()) {
                    Text("Your installed apps will appear here.", color = Muted, fontSize = 16.sp)
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        apps.take(4).forEach { app ->
                            AppTile(app, favorites.contains(app.packageName), onLaunch, onToggleFavorite)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("${allApps.size} launchable apps found", color = Muted, fontSize = 12.sp)
            }
            Column(
                modifier = Modifier.weight(0.8f)
                    .background(Color(0xFF101214), RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF33383D), RoundedCornerShape(18.dp))
                    .padding(22.dp)
            ) {
                Text("QUICK ACCESS", color = Silver, fontSize = 11.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(16.dp))
                ActionTile("Browse applications", "Open your installed apps", onShowApps)
                Spacer(Modifier.height(10.dp))
                Text("Weather and recent activity are not shown until real data sources are implemented.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun AppsPage(
    apps: List<AppInfo>,
    favorites: Set<String>,
    onLaunch: (String) -> Unit,
    onToggleFavorite: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Applications", color = White, fontSize = 30.sp, fontWeight = FontWeight.Light)
        Text("${apps.size} installed launchable apps", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        if (apps.isEmpty()) {
            Text("No launchable applications were found.", color = Muted)
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 150.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(apps, key = { it.packageName }) { app ->
                    AppTile(app, favorites.contains(app.packageName), onLaunch, onToggleFavorite)
                }
            }
        }
    }
}

@Composable
private fun AppTile(
    app: AppInfo,
    favorite: Boolean,
    onLaunch: (String) -> Unit,
    onToggleFavorite: (String) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val appIcon = remember(app.packageName) {
        runCatching {
            context.packageManager.getApplicationIcon(app.packageName).toBitmap(96, 96).asImageBitmap()
        }.getOrNull()
    }
    val scale by animateFloatAsState(if (focused) 1.035f else 1f, label = "tileScale")
    Column(
        modifier = Modifier.width(126.dp)
            .scale(scale)
            .background(if (focused) Color(0xFF292D31) else Panel, RoundedCornerShape(14.dp))
            .border(1.dp, if (focused) Silver else Color(0xFF33383D), RoundedCornerShape(14.dp))
            .onFocusChanged { focused = it.isFocused }
            .onKeyEvent { event ->
                if (event.key == Key.Menu && event.type == KeyEventType.KeyUp) {
                    onToggleFavorite(app.packageName)
                    true
                } else false
            }
            .clickable { onLaunch(app.packageName) }
            .focusable()
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(58.dp)
                .background(Color(0xFF303438), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (appIcon != null) {
                Image(
                    bitmap = appIcon,
                    contentDescription = "${app.label} icon",
                    modifier = Modifier.fillMaxSize().padding(7.dp),
                    contentScale = ContentScale.Fit
                )
            } else {
                Text(app.label.take(1).uppercase(), color = White, fontSize = 26.sp, fontWeight = FontWeight.Light)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(app.label, color = White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(if (favorite) "FAVOURITE" else "MENU: FAVOURITE", color = if (favorite) Silver else Muted, fontSize = 8.sp)
    }
}

@Composable
private fun ActionTile(title: String, subtitle: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxWidth()
            .background(if (focused) Color(0xFF292D31) else Panel, RoundedCornerShape(12.dp))
            .border(1.dp, if (focused) Silver else Color(0xFF33383D), RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .focusable()
            .padding(14.dp)
    ) {
        Text(title, color = White, fontSize = 15.sp)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun NavigationBar(current: String, onSelect: (String) -> Unit) {
    val items = listOf("HOME", "APPS", "GAMES", "DISCOVER", "SETTINGS")
    Row(
        modifier = Modifier.fillMaxWidth()
            .background(Color(0xFF111315), RoundedCornerShape(16.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { item ->
            var focused by remember { mutableStateOf(false) }
            Text(
                item,
                color = if (current == item || focused) White else Muted,
                fontSize = 12.sp,
                fontWeight = if (current == item) FontWeight.Bold else FontWeight.Medium,
                letterSpacing = 1.5.sp,
                modifier = Modifier
                    .background(if (current == item || focused) Color(0xFF303438) else Color.Transparent, RoundedCornerShape(10.dp))
                    .border(if (focused) 1.dp else 0.dp, if (focused) Silver else Color.Transparent, RoundedCornerShape(10.dp))
                    .onFocusChanged { focused = it.isFocused }
                    .clickable { onSelect(item) }
                    .focusable()
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            )
        }
    }
}

@Composable
private fun SimplePage(page: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 30.dp)) {
        Text(page.lowercase().replaceFirstChar { it.uppercase() }, color = White, fontSize = 30.sp)
        Spacer(Modifier.height(10.dp))
        Text("This section is scheduled for Stage 2. The launcher foundation remains available.", color = Muted, fontSize = 15.sp)
    }
}
