package com.saii.saiiostv

data class AppInfo(
    val label: String,
    val packageName: String
)
