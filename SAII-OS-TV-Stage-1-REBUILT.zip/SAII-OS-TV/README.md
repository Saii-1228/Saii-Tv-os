# SAII OS TV — Stage 1 foundation

Native Android launcher foundation written in Kotlin and Jetpack Compose.

## Package
`com.saii.saiiostv`

## Stage 1 features
- HOME/DEFAULT launcher intent candidate
- Android TV Leanback launcher entry
- Discovery of installed launcher activities using package visibility queries
- Launching installed apps through PackageManager
- D-pad-focusable dashboard and navigation
- DataStore-backed favourite package list
- GitHub Actions debug APK workflow

## Phone-only GitHub upload (ZIP bootstrap)
1. Create a GitHub repository from your phone.
2. Upload `SAII-OS-TV-Stage-1.zip` to the repository root.
3. In GitHub, choose **Add file → Create new file**.
4. Set the filename to `.github/workflows/android.yml`.
5. Paste the workflow from this project's `.github/workflows/android.yml` file (or use the separate workflow file supplied with this project).
6. Commit the file to the `main` branch.
7. Open **Actions**, select **Build SAII OS TV APK**, then choose **Run workflow**.
8. Open the successful run and download the `saii-os-tv-debug-apk` artifact.

The workflow detects the ZIP, extracts the project in the cloud, and builds it. You do not need Android Studio, a PC, or a local terminal.

## Important
This is an application launcher, not firmware. It does not replace Android, alter system partitions, or disable the manufacturer's launcher. Whether Android lets it become the default HOME app depends on the TV firmware and user-selectable Home-app settings.

The app discovery list is limited to applications that expose standard `LEANBACK_LAUNCHER` or `LAUNCHER` activities. Some manufacturer or sideloaded apps may not expose a launchable activity.

Stage 1 has not been compiled or tested on a Thomson TV in this environment. The GitHub Actions build is the first compilation check; device compatibility must then be verified on the actual TV.
