# SAII OS TV — Stage 2

Native Android launcher written in Kotlin and Jetpack Compose.

## Package
`com.saii.saiiostv`

## Stage 2 features
- HOME/DEFAULT launcher candidate and Android TV Leanback launcher entry
- Installed-app discovery from real `LEANBACK_LAUNCHER` and `LAUNCHER` activities
- Search by app name or package name
- Android application metadata categories in Apps and Discover
- Real app icons and launch intents from PackageManager
- D-pad-focusable and touch-operable navigation, tiles, and controls
- Persistent favourites and manually selected Games shelf
- User-created collections: create, delete, and add/remove installed apps
- Existing Stage 1 favourite DataStore name and key are preserved
- GitHub Actions debug APK workflow

## Build setup
- Android Gradle Plugin 9.3.1
- Gradle 9.5.0 (required minimum for AGP 9.3)
- Built-in Kotlin support from AGP 9; the old `org.jetbrains.kotlin.android` plugin is intentionally not applied
- Kotlin Compose compiler plugin 2.4.21
- Compose BOM 2026.09.00
- compileSdk 37, targetSdk 35, minSdk 23
- Java 17

## Phone-only GitHub build
1. Create a GitHub repository from your phone.
2. Upload `SAII-OS-TV-Stage-2.zip` to the repository root.
3. In GitHub, choose **Add file → Create new file**.
4. Set the filename to `.github/workflows/android.yml`.
5. Paste the workflow from this project's `.github/workflows/android.yml` file.
6. Commit the file to the `main` branch.
7. Open **Actions**, choose **Build SAII OS TV APK**, then choose **Run workflow**.
8. Open the run and download the `saii-os-tv-debug-apk` artifact.

If you already uploaded the Stage 1 ZIP and workflow, replace the ZIP with Stage 2 using the same filename or update the workflow's ZIP filename to match. Do not upload both archives under the same root if the workflow is configured to extract only one.

## Important limitations
This is an application launcher, not firmware. It does not replace Android, modify system partitions, or disable the manufacturer's launcher. Whether it can become the default HOME app depends on the TV firmware and the user's Home-app settings.

The Apps list only includes apps that expose standard `LEANBACK_LAUNCHER` or `LAUNCHER` activities and are visible under Android package-visibility rules. Some manufacturer or sideloaded apps may not appear.

Games are manually labelled by the user; the launcher does not assume that an Android metadata category is a user's preferred game list. Discover categories are based on Android's app metadata. Custom collections are stored locally in DataStore; they do not create Android pinned shortcuts outside this app.

Stage 2 source has not been compiled in this environment or tested on a Thomson TV. The GitHub Actions run is the first real compilation check. TV compatibility remains unverified until installed and tested on the actual TV.
