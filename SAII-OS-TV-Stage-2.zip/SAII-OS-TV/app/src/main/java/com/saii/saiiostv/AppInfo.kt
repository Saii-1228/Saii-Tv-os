package com.saii.saiiostv

data class AppInfo(
    val label: String,
    val packageName: String,
    val category: Int
)

object AppCategory {
    const val ALL = "ALL"
    const val SYSTEM_GAMES = "SYSTEM_GAMES"
    const val MEDIA = "MEDIA"
    const val PRODUCTIVITY = "PRODUCTIVITY"
    const val SOCIAL = "SOCIAL"
    const val NEWS = "NEWS"
    const val MAPS = "MAPS"
    const val ACCESSIBILITY = "ACCESSIBILITY"
    const val OTHER = "OTHER"
}
