package com.saii.saiiostv

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build

class AppRepository(private val context: Context) {
    fun loadLaunchableApps(): List<AppInfo> {
        val pm = context.packageManager
        val candidates = linkedMapOf<String, AppInfo>()

        fun addFor(category: String) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            val resolved = if (Build.VERSION.SDK_INT >= 33) {
                pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(intent, 0)
            }
            resolved.forEach { info ->
                val activityInfo = info.activityInfo ?: return@forEach
                val packageName = activityInfo.packageName
                if (packageName == context.packageName) return@forEach
                val label = info.loadLabel(pm)?.toString()?.trim().orEmpty()
                if (label.isNotBlank()) {
                    val categoryValue = try {
                        val applicationInfo = if (Build.VERSION.SDK_INT >= 33) {
                            pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
                        } else {
                            @Suppress("DEPRECATION")
                            pm.getApplicationInfo(packageName, 0)
                        }
                        if (Build.VERSION.SDK_INT >= 26) applicationInfo.category else ApplicationInfo.CATEGORY_UNDEFINED
                    } catch (_: Exception) {
                        ApplicationInfo.CATEGORY_UNDEFINED
                    }
                    candidates[packageName] = AppInfo(label, packageName, categoryValue)
                }
            }
        }

        addFor(Intent.CATEGORY_LEANBACK_LAUNCHER)
        addFor(Intent.CATEGORY_LAUNCHER)
        return candidates.values.sortedBy { it.label.lowercase() }
    }

    fun launch(packageName: String): Boolean {
        val intent = context.packageManager.getLeanbackLaunchIntentForPackage(packageName)
            ?: context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }
}
