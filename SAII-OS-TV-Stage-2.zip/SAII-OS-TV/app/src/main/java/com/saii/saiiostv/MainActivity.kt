package com.saii.saiiostv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF050505)
private val Panel = Color(0xFF17191B)
private val Silver = Color(0xFFC4C8CC)
private val Muted = Color(0xFF858A90)
private val White = Color(0xFFF5F5F5)

class MainActivity : ComponentActivity() {
    private lateinit var repository: AppRepository
    private lateinit var libraryStore: LibraryStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = AppRepository(this)
        libraryStore = LibraryStore(this)
        setContent {
            MaterialTheme {
                LauncherRoot(repository = repository, libraryStore = libraryStore)
            }
        }
    }
}

@Composable
private fun LauncherRoot(repository: AppRepository, libraryStore: LibraryStore) {
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var page by remember { mutableStateOf("HOME") }
    var message by remember { mutableStateOf<String?>(null) }
    var selectedCategory by remember { mutableStateOf(AppCategory.ALL) }
    var refreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val favourites by libraryStore.favourites.collectAsState(initial = emptySet())
    val games by libraryStore.games.collectAsState(initial = emptySet())
    val collections by libraryStore.collections.collectAsState(initial = emptyMap())
    var activeCollection by remember { mutableStateOf<String?>(null) }

    suspend fun refreshApps() {
        refreshing = true
        apps = withContext(Dispatchers.IO) { repository.loadLaunchableApps() }
        refreshing = false
    }

    LaunchedEffect(Unit) { refreshApps() }
    BackHandler(enabled = page != "HOME") {
        if (page == "APPS" && activeCollection != null) {
            page = "DISCOVER"
            activeCollection = null
        } else {
            page = "HOME"
            selectedCategory = AppCategory.ALL
            activeCollection = null
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 44.dp, vertical = 24.dp)
        ) {
            Header()
            Spacer(Modifier.height(18.dp))
            when (page) {
                "HOME" -> HomePage(
                    apps = apps.filter { it.packageName in favourites },
                    allApps = apps,
                    gamesCount = games.count { pkg -> apps.any { it.packageName == pkg } },
                    onLaunch = { pkg -> message = if (repository.launch(pkg)) null else "This app could not be opened." },
                    onOpen = { page = "APPS" },
                    onRefresh = { scope.launch { refreshApps() } }
                )
                "APPS" -> AppsPage(
                    apps = apps,
                    favourites = favourites,
                    games = games,
                    selectedCategory = selectedCategory,
                    onCategoryChange = { selectedCategory = it },
                    onLaunch = { pkg -> message = if (repository.launch(pkg)) null else "This app could not be opened." },
                    onToggleFavourite = { pkg -> scope.launch { libraryStore.toggleFavourite(pkg) } },
                    onToggleGame = { pkg -> scope.launch { libraryStore.toggleGame(pkg) } },
                    collectionName = activeCollection,
                    collectionPackages = activeCollection?.let { collections[it] ?: emptySet() } ?: emptySet(),
                    onToggleCollection = { pkg -> activeCollection?.let { name -> scope.launch { libraryStore.toggleCollectionApp(name, pkg) } } },
                    onFinishCollection = { activeCollection = null; page = "DISCOVER" }
                )
                "GAMES" -> GamesPage(
                    apps = apps.filter { it.packageName in games },
                    favourites = favourites,
                    games = games,
                    onLaunch = { pkg -> message = if (repository.launch(pkg)) null else "This app could not be opened." },
                    onToggleFavourite = { pkg -> scope.launch { libraryStore.toggleFavourite(pkg) } },
                    onRemoveGame = { pkg -> scope.launch { libraryStore.toggleGame(pkg) } },
                    onBrowseApps = { page = "APPS" }
                )
                "DISCOVER" -> DiscoverPage(
                    apps = apps,
                    games = games,
                    favourites = favourites,
                    collections = collections,
                    onBrowseCategory = { category -> activeCollection = null; selectedCategory = category; page = "APPS" },
                    onCreateCollection = { name -> scope.launch { if (!libraryStore.createCollection(name)) message = "Use a new collection name (up to 28 characters)." else message = "Collection created." } },
                    onDeleteCollection = { name -> scope.launch { libraryStore.deleteCollection(name) } },
                    onOpenCollection = { name -> activeCollection = name; selectedCategory = AppCategory.ALL; page = "APPS" }
                )
                else -> SettingsPage(apps.size, favourites.size, games.count { pkg -> apps.any { it.packageName == pkg } }, refreshing)
            }
            Spacer(Modifier.height(14.dp))
            NavigationBar(current = page, onSelect = { page = it; selectedCategory = AppCategory.ALL; activeCollection = null })
            message?.let {
                Text(it, color = Silver, modifier = Modifier.padding(top = 8.dp), fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun Header() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = Date()
        }
    }
    val time = remember(now) { SimpleDateFormat("h:mm", Locale.getDefault()).format(now) }
    val date = remember(now) { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column {
            Text("SAII OS", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("TELEVISION", color = Muted, fontSize = 10.sp, letterSpacing = 4.sp)
        }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(time, color = White, fontSize = 22.sp, fontWeight = FontWeight.Light)
            Text(date, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun HomePage(
    apps: List<AppInfo>,
    allApps: List<AppInfo>,
    gamesCount: Int,
    onLaunch: (String) -> Unit,
    onOpen: () -> Unit,
    onRefresh: () -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Text("A calmer way to watch.", color = White, fontSize = 34.sp, fontWeight = FontWeight.Light)
        Text("YOUR TELEVISION. YOUR SPACE.", color = Muted, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(
                Modifier.weight(1.3f).background(Panel, RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF33383D), RoundedCornerShape(18.dp)).padding(20.dp)
            ) {
                Text("FAVOURITES", color = Silver, fontSize = 11.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(14.dp))
                if (apps.isEmpty()) {
                    Text("No favourites yet. Open Apps and mark a few with the FAV button.", color = Muted, fontSize = 15.sp)
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        apps.take(4).forEach { app -> AppTile(app, true, false, onLaunch, {}, {}, showActions = false) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("${allApps.size} apps  ·  $gamesCount games", color = Muted, fontSize = 12.sp)
            }
            Column(
                Modifier.weight(0.8f).background(Color(0xFF101214), RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF33383D), RoundedCornerShape(18.dp)).padding(20.dp)
            ) {
                Text("QUICK ACCESS", color = Silver, fontSize = 11.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(12.dp))
                ActionTile("Browse applications", "Search and organise apps", onOpen)
                Spacer(Modifier.height(9.dp))
                ActionTile("Refresh library", "Check for newly installed apps", onRefresh)
                Spacer(Modifier.height(12.dp))
                Text("Your favourites and game list stay on this device.", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun AppsPage(
    apps: List<AppInfo>,
    favourites: Set<String>,
    games: Set<String>,
    selectedCategory: String,
    onCategoryChange: (String) -> Unit,
    onLaunch: (String) -> Unit,
    onToggleFavourite: (String) -> Unit,
    onToggleGame: (String) -> Unit,
    collectionName: String?,
    collectionPackages: Set<String>,
    onToggleCollection: (String) -> Unit,
    onFinishCollection: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = apps.filter { app ->
        val matchesQuery = query.isBlank() || app.label.contains(query, true) || app.packageName.contains(query, true)
        matchesQuery && matchesCategory(app, selectedCategory)
    }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Applications", color = White, fontSize = 30.sp, fontWeight = FontWeight.Light)
                Text(
                    if (collectionName == null) "${filtered.size} of ${apps.size} launchable apps" else "Add apps to $collectionName",
                    color = Muted,
                    fontSize = 12.sp
                )
            }
            Spacer(Modifier.weight(1f))
            if (collectionName != null) {
                Box(Modifier.width(112.dp)) {
                    ActionTile("Done", "Return to Discover", onFinishCollection)
                }
                Spacer(Modifier.width(10.dp))
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                label = { Text("Search apps") },
                modifier = Modifier.width(260.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = White,
                    unfocusedTextColor = White,
                    focusedBorderColor = Silver,
                    unfocusedBorderColor = Color(0xFF4A4F54),
                    focusedLabelColor = Silver,
                    unfocusedLabelColor = Muted,
                    cursorColor = White
                )
            )
        }
        Spacer(Modifier.height(12.dp))
        CategoryBar(selectedCategory, onCategoryChange)
        Spacer(Modifier.height(12.dp))
        if (filtered.isEmpty()) {
            Text(if (apps.isEmpty()) "No launchable applications were found." else "No apps match this search or category.", color = Muted)
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 174.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filtered, key = { it.packageName }) { app ->
                    AppTile(
                        app,
                        app.packageName in favourites,
                        app.packageName in games,
                        onLaunch,
                        onToggleFavourite,
                        onToggleGame,
                        collectionName = collectionName,
                        inCollection = app.packageName in collectionPackages,
                        onToggleCollection = onToggleCollection
                    )
                }
            }
        }
    }
}

@Composable
private fun GamesPage(
    apps: List<AppInfo>,
    favourites: Set<String>,
    games: Set<String>,
    onLaunch: (String) -> Unit,
    onToggleFavourite: (String) -> Unit,
    onRemoveGame: (String) -> Unit,
    onBrowseApps: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Text("Games", color = White, fontSize = 30.sp, fontWeight = FontWeight.Light)
        Text("Only apps you mark as games appear here.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        if (apps.isEmpty()) {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(22.dp)) {
                Text("Your game shelf is empty", color = White, fontSize = 19.sp)
                Spacer(Modifier.height(6.dp))
                Text("Go to Apps and tap GAME on any installed app to add it. Nothing is auto-labelled.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                ActionTile("Choose games", "Open your installed apps", onBrowseApps)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 174.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(apps, key = { it.packageName }) { app ->
                    AppTile(app, app.packageName in favourites, app.packageName in games, onLaunch, onToggleFavourite, onRemoveGame)
                }
            }
        }
    }
}

@Composable
private fun DiscoverPage(
    apps: List<AppInfo>,
    games: Set<String>,
    favourites: Set<String>,
    collections: Map<String, Set<String>>,
    onBrowseCategory: (String) -> Unit,
    onCreateCollection: (String) -> Unit,
    onDeleteCollection: (String) -> Unit,
    onOpenCollection: (String) -> Unit
) {
    var newCollectionName by remember { mutableStateOf("") }
    val categories = listOf(
        AppCategory.SYSTEM_GAMES to "Android-labelled games",
        AppCategory.MEDIA to "Media & entertainment",
        AppCategory.PRODUCTIVITY to "Productivity",
        AppCategory.SOCIAL to "Social",
        AppCategory.NEWS to "News",
        AppCategory.MAPS to "Maps & navigation",
        AppCategory.ACCESSIBILITY to "Accessibility",
        AppCategory.OTHER to "Other apps"
    )
    Column(Modifier.fillMaxSize()) {
        Text("Discover", color = White, fontSize = 30.sp, fontWeight = FontWeight.Light)
        Text("Explore installed apps and build your own collections.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("INSTALLED", apps.size.toString(), Modifier.weight(1f))
            StatCard("FAVOURITES", favourites.size.toString(), Modifier.weight(1f))
            StatCard("GAMES", games.count { pkg -> apps.any { it.packageName == pkg } }.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        Text("YOUR COLLECTIONS", color = Silver, fontSize = 11.sp, letterSpacing = 2.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = newCollectionName,
                onValueChange = { newCollectionName = it.take(28) },
                singleLine = true,
                label = { Text("New collection name") },
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = White,
                    unfocusedTextColor = White,
                    focusedBorderColor = Silver,
                    unfocusedBorderColor = Color(0xFF4A4F54),
                    focusedLabelColor = Silver,
                    unfocusedLabelColor = Muted,
                    cursorColor = White
                )
            )
            Box(Modifier.width(112.dp)) {
                ActionTile("Create", "Save collection", {
                    val name = newCollectionName.trim()
                    if (name.isNotEmpty()) {
                        onCreateCollection(name)
                        newCollectionName = ""
                    }
                })
            }
        }
        if (collections.isEmpty()) {
            Text("No custom collections yet. Create one, then choose which installed apps belong in it.", color = Muted, fontSize = 12.sp)
        } else {
            LazyColumn(
                Modifier.heightIn(max = 130.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(vertical = 6.dp)
            ) {
                items(collections.keys.sorted(), key = { it }) { name ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.weight(1f)) {
                            ActionTile(
                                name,
                                "${collections[name]?.count { pkg -> apps.any { it.packageName == pkg } } ?: 0} installed apps · Open to organise",
                                { onOpenCollection(name) }
                            )
                        }
                        SmallAction("DELETE", false) { onDeleteCollection(name) }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("BROWSE BY ANDROID CATEGORY", color = Silver, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 8.dp)) {
            items(categories.size) { index ->
                val (category, title) = categories[index]
                val count = apps.count { matchesCategory(it, category) }
                if (count > 0) ActionTile(title, "$count installed apps", { onBrowseCategory(category) })
            }
        }
        Text("Android categories come from app metadata. Your custom Games shelf and collections are saved separately on this device.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun SettingsPage(appCount: Int, favouriteCount: Int, gameCount: Int, refreshing: Boolean) {
    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Text("Settings", color = White, fontSize = 30.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(14.dp))
        Text("SAII OS TV · Stage 2", color = Silver, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))
        Text("Installed launchable apps: $appCount", color = Muted, fontSize = 13.sp)
        Text("Saved favourites: $favouriteCount", color = Muted, fontSize = 13.sp)
        Text("Manually labelled games: $gameCount", color = Muted, fontSize = 13.sp)
        Text(if (refreshing) "Refreshing app library…" else "Library refresh is available from Home.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Text("Privacy: SAII OS TV reads launchable app names and icons on this device. It does not upload your app list.", color = Silver, fontSize = 13.sp)
    }
}

@Composable
private fun CategoryBar(selected: String, onSelect: (String) -> Unit) {
    val items = listOf(
        AppCategory.ALL to "ALL",
        AppCategory.SYSTEM_GAMES to "ANDROID GAMES",
        AppCategory.MEDIA to "MEDIA",
        AppCategory.PRODUCTIVITY to "PRODUCTIVITY",
        AppCategory.SOCIAL to "SOCIAL",
        AppCategory.NEWS to "NEWS",
        AppCategory.MAPS to "MAPS",
        AppCategory.ACCESSIBILITY to "ACCESSIBILITY",
        AppCategory.OTHER to "OTHER"
    )
    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        items.forEach { (value, label) ->
            var focused by remember { mutableStateOf(false) }
            Box(
                Modifier.background(if (selected == value || focused) Color(0xFF303438) else Panel, RoundedCornerShape(9.dp))
                    .border(1.dp, if (focused) Silver else Color(0xFF33383D), RoundedCornerShape(9.dp))
                    .onFocusChanged { focused = it.isFocused }
                    .clickable { onSelect(value) }
                    .focusable()
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) { Text(label, color = if (selected == value || focused) White else Muted, fontSize = 9.sp, letterSpacing = 0.6.sp) }
        }
    }
}

@Composable
private fun AppTile(
    app: AppInfo,
    favourite: Boolean,
    game: Boolean,
    onLaunch: (String) -> Unit,
    onToggleFavourite: (String) -> Unit,
    onToggleGame: (String) -> Unit,
    showActions: Boolean = true,
    collectionName: String? = null,
    inCollection: Boolean = false,
    onToggleCollection: (String) -> Unit = {}
) {
    var focused by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val appIcon = remember(app.packageName) {
        runCatching { context.packageManager.getApplicationIcon(app.packageName).toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    val scale by animateFloatAsState(if (focused) 1.025f else 1f, label = "appTileScale")
    Column(
        Modifier.width(160.dp).scale(scale)
            .background(if (focused) Color(0xFF292D31) else Panel, RoundedCornerShape(14.dp))
            .border(1.dp, if (focused) Silver else Color(0xFF33383D), RoundedCornerShape(14.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable { onLaunch(app.packageName) }
            .focusable()
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(56.dp).background(Color(0xFF303438), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
            if (appIcon != null) {
                Image(appIcon, contentDescription = "${app.label} icon", modifier = Modifier.fillMaxSize().padding(6.dp), contentScale = ContentScale.Fit)
            } else {
                Text(app.label.take(1).uppercase(), color = White, fontSize = 25.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(app.label, color = White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(8.dp))
        if (showActions) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SmallAction(if (favourite) "FAV ✓" else "FAV", favourite) { onToggleFavourite(app.packageName) }
                SmallAction(if (game) "GAME ✓" else "GAME", game) { onToggleGame(app.packageName) }
                if (collectionName != null) {
                    SmallAction(if (inCollection) "IN ✓" else "ADD", inCollection) { onToggleCollection(app.packageName) }
                }
            }
        }
    }
}

@Composable
private fun SmallAction(label: String, active: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.background(if (focused || active) Color(0xFF394047) else Color(0xFF24282C), RoundedCornerShape(6.dp))
            .border(1.dp, if (focused) Silver else Color(0xFF3B4147), RoundedCornerShape(6.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = 7.dp, vertical = 6.dp)
    ) { Text(label, color = if (active || focused) White else Muted, fontSize = 8.sp, letterSpacing = 0.3.sp) }
}

@Composable
private fun ActionTile(title: String, subtitle: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().background(if (focused) Color(0xFF292D31) else Panel, RoundedCornerShape(12.dp))
            .border(1.dp, if (focused) Silver else Color(0xFF33383D), RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick).focusable().padding(13.dp)
    ) {
        Text(title, color = White, fontSize = 14.sp)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(12.dp)).padding(14.dp)) {
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.2.sp)
        Text(value, color = White, fontSize = 23.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun NavigationBar(current: String, onSelect: (String) -> Unit) {
    val items = listOf("HOME", "APPS", "GAMES", "DISCOVER", "SETTINGS")
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF111315), RoundedCornerShape(16.dp)).padding(horizontal = 8.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { item ->
            var focused by remember { mutableStateOf(false) }
            Text(
                item,
                color = if (current == item || focused) White else Muted,
                fontSize = 11.sp,
                fontWeight = if (current == item) FontWeight.Bold else FontWeight.Medium,
                letterSpacing = 1.2.sp,
                modifier = Modifier.background(if (current == item || focused) Color(0xFF303438) else Color.Transparent, RoundedCornerShape(9.dp))
                    .border(if (focused) 1.dp else 0.dp, if (focused) Silver else Color.Transparent, RoundedCornerShape(9.dp))
                    .onFocusChanged { focused = it.isFocused }
                    .clickable { onSelect(item) }.focusable().padding(horizontal = 17.dp, vertical = 11.dp)
            )
        }
    }
}

private fun matchesCategory(app: AppInfo, category: String): Boolean {
    return when (category) {
        AppCategory.ALL -> true
        AppCategory.SYSTEM_GAMES -> app.category == android.content.pm.ApplicationInfo.CATEGORY_GAME
        AppCategory.MEDIA -> app.category == android.content.pm.ApplicationInfo.CATEGORY_AUDIO ||
            app.category == android.content.pm.ApplicationInfo.CATEGORY_VIDEO ||
            app.category == android.content.pm.ApplicationInfo.CATEGORY_IMAGE
        AppCategory.PRODUCTIVITY -> app.category == android.content.pm.ApplicationInfo.CATEGORY_PRODUCTIVITY
        AppCategory.SOCIAL -> app.category == android.content.pm.ApplicationInfo.CATEGORY_SOCIAL
        AppCategory.NEWS -> app.category == android.content.pm.ApplicationInfo.CATEGORY_NEWS
        AppCategory.MAPS -> app.category == android.content.pm.ApplicationInfo.CATEGORY_MAPS
        AppCategory.ACCESSIBILITY -> app.category == android.content.pm.ApplicationInfo.CATEGORY_ACCESSIBILITY
        AppCategory.OTHER -> app.category == android.content.pm.ApplicationInfo.CATEGORY_UNDEFINED || app.category < 0
        else -> false
    }
}
