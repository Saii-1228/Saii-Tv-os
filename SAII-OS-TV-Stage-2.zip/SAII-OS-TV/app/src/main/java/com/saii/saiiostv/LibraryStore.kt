package com.saii.saiiostv

import android.content.Context
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// Keep the original DataStore name and favourite key so Stage 1 favourites survive.
private val Context.libraryDataStore by preferencesDataStore(name = "saii_launcher")

class LibraryStore(private val context: Context) {
    private val favouritesKey = stringSetPreferencesKey("favorite_packages")
    private val gamesKey = stringSetPreferencesKey("game_packages")
    private val collectionNamesKey = stringSetPreferencesKey("collection_names")

    val favourites: Flow<Set<String>> = context.libraryDataStore.data.map {
        it[favouritesKey] ?: emptySet()
    }

    val games: Flow<Set<String>> = context.libraryDataStore.data.map {
        it[gamesKey] ?: emptySet()
    }

    val collections: Flow<Map<String, Set<String>>> = context.libraryDataStore.data.map { preferences ->
        (preferences[collectionNamesKey] ?: emptySet()).associateWith { name ->
            preferences[collectionPackagesKey(name)] ?: emptySet()
        }
    }

    suspend fun toggleFavourite(packageName: String) {
        context.libraryDataStore.edit { preferences ->
            val updated = (preferences[favouritesKey] ?: emptySet()).toMutableSet()
            if (!updated.add(packageName)) updated.remove(packageName)
            preferences[favouritesKey] = updated
        }
    }

    suspend fun toggleGame(packageName: String) {
        context.libraryDataStore.edit { preferences ->
            val updated = (preferences[gamesKey] ?: emptySet()).toMutableSet()
            if (!updated.add(packageName)) updated.remove(packageName)
            preferences[gamesKey] = updated
        }
    }

    suspend fun createCollection(rawName: String): Boolean {
        val name = rawName.trim().replace(Regex("\\s+"), " ")
        if (name.isBlank() || name.length > 28) return false
        var created = false
        context.libraryDataStore.edit { preferences ->
            val names = (preferences[collectionNamesKey] ?: emptySet()).toMutableSet()
            if (names.none { it.equals(name, ignoreCase = true) }) {
                names.add(name)
                preferences[collectionNamesKey] = names
                preferences[collectionPackagesKey(name)] = emptySet()
                created = true
            }
        }
        return created
    }

    suspend fun deleteCollection(name: String) {
        context.libraryDataStore.edit { preferences ->
            val names = (preferences[collectionNamesKey] ?: emptySet()).toMutableSet()
            names.remove(name)
            preferences[collectionNamesKey] = names
            preferences.remove(collectionPackagesKey(name))
        }
    }

    suspend fun toggleCollectionApp(name: String, packageName: String) {
        context.libraryDataStore.edit { preferences ->
            val names = preferences[collectionNamesKey] ?: emptySet()
            if (name !in names) return@edit
            val key = collectionPackagesKey(name)
            val packages = (preferences[key] ?: emptySet()).toMutableSet()
            if (!packages.add(packageName)) packages.remove(packageName)
            preferences[key] = packages
        }
    }

    private fun collectionPackagesKey(name: String) = stringSetPreferencesKey(
        "collection_${Base64.encodeToString(name.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)}"
    )
}
